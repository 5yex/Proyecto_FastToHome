/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import com.google.gson.Gson;
import java.util.Date;

/**
 *
 * @author jmcbg
 */
public class Pedido {
    private int id_pedido;
    private int id_usuario;
    private int id_negocio;
    private Date fecha_hora;
    private String estado;
    private double total;
    private String transporte;

    public Pedido() {
    }

    public Pedido(int id_pedido, int id_usuario, int id_negocio, Date fecha_hora, String estado, double total, String transporte) {
        this.id_pedido = id_pedido;
        this.id_usuario = id_usuario;
        this.id_negocio = id_negocio;
        this.fecha_hora = fecha_hora;
        this.estado = estado;
        this.total = total;
        this.transporte = transporte;
    }

    public Pedido(int id_usuario, int id_negocio, Date fecha_hora, String estado, double total, String transporte) {
        this.id_usuario = id_usuario;
        this.id_negocio = id_negocio;
        this.fecha_hora = fecha_hora;
        this.estado = estado;
        this.total = total;
        this.transporte = transporte;
    }
    

    public int getId_pedido() {
        return id_pedido;
    }

    public void setId_pedido(int id_pedido) {
        this.id_pedido = id_pedido;
    }

    public int getId_usuario() {
        return id_usuario;
    }

    public void setId_usuario(int id_usuario) {
        this.id_usuario = id_usuario;
    }

    public int getId_negocio() {
        return id_negocio;
    }

    public void setId_negocio(int id_negocio) {
        this.id_negocio = id_negocio;
    }

    public Date getFecha_hora() {
        return fecha_hora;
    }

    public void setFecha_hora(Date fecha_hora) {
        this.fecha_hora = fecha_hora;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public double getTotal() {
        return total;
    }

    public void setTotal(double total) {
        this.total = total;
    }

    public String getTransporte() {
        return transporte;
    }

    public void setTransporte(String transporte) {
        this.transporte = transporte;
    }
    
    public String getJSON(){
       return new Gson().toJson(this);
    }
    
    public Object[] getRow() {
        return new Object[]{id_pedido, id_usuario, transporte, total, fecha_hora, estado};
    }

    @Override
    public String toString() {
        return "Pedido{" + "id_pedido=" + id_pedido + ", id_usuario=" + id_usuario + ", id_negocio=" + id_negocio + ", fecha_hora=" + fecha_hora + ", estado=" + estado + ", total=" + total + ", transporte=" + transporte + '}';
    }
    
    
    
}

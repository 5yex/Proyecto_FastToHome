package modelo;

public class Oficina {
	private int cod_oficina;
	private String ciudad;
	private String pais;
	private String dni;
	
	public Oficina() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Oficina(int cod_oficina, String ciudad, String pais, String dni) {
		super();
		this.cod_oficina = cod_oficina;
		this.ciudad = ciudad;
		this.pais = pais;
		this.dni = dni;
	}

	public int getCod_oficina() {
		return cod_oficina;
	}

	public void setCod_oficina(int cod_oficina) {
		this.cod_oficina = cod_oficina;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public String getDni() {
		return dni;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	@Override
	public String toString() {
		return "Oficina [cod_oficina=" + cod_oficina + ", ciudad=" + ciudad + ", pais=" + pais + ", dni=" + dni + "]";
	}
	
	

}

package vista;

import java.io.IOException;
import controlador.GestionCoordinador;
import modelo.Coordinador;
import modelo.Oficina;

/**
 * 
 * @author encarna
 *
 */
public class VentanaPrincipal {

	public static boolean loguear() {
		String dni = pedirDNI();

		boolean resultado = GestionCoordinador.logear(dni);

		return resultado;

	}

	public static String pedirDNI() {
		String dni = null;
		boolean correctodni = false;

		// do {

		System.out.println("Dame tu dni:");
		try {
			dni = Utilidades.teclado.readLine();
//			
//			 correctodni = ValidarDatos.comprobarDni(dni);
//			

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// }while (!correctodni);

		return dni;
	}

	public static String pedirNombre() {
		String nombre = "";
		System.out.println("Inserta el nombre:");
		try {
			nombre = Utilidades.teclado.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return nombre;
	}
	
	public static String pedirCiudad() {
		String nombre = "";
		System.out.println("Inserta la ciudad:");
		try {
			nombre = Utilidades.teclado.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return nombre;
	}
	
	public static String pedirPais() {
		String nombre = "";
		System.out.println("Inserta el pais:");
		try {
			nombre = Utilidades.teclado.readLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return nombre;
	}
	
	public static int pedirCodigoOficina() {
		int cod = 0;
		System.out.println("Inserta el codigo de oficina:");
		try {
			cod = Integer.parseInt(Utilidades.teclado.readLine());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cod;
	}
	
	public static int pedirIdProyecto() {
		int cod = 0;
		System.out.println("Inserta el id de proyecto:");
		try {
			cod = Integer.parseInt(Utilidades.teclado.readLine());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return cod;
	}

	public static Coordinador leerCoor() {
		String dni = pedirDNI();
		String nombre = pedirNombre();
		int proyecto = pedirIdProyecto();
		return new Coordinador(dni, nombre,proyecto);
	}
	
	public static Oficina leerOficina() {
		int cod = pedirCodigoOficina();
		String ciudad = pedirCiudad();
		String pais = pedirPais();
		String dni = pedirDNI();
		
		return new Oficina(cod,ciudad,pais,dni);
	}

	/**
	 * Menu de opciones VentanaPrincipal
	 * 
	 * @return
	 */
	public static int menu() {
		System.out.println("Gestionar: ");
		System.out.println("1. Insertar Coordinador");
		System.out.println("2. Borrar Coordinador");
		System.out.println("3. Modificar Coordinador");
		System.out.println("4. Insertar Oficina");
		System.out.println("5. Borrar Oficina");
		System.out.println("6. Modificar Oficina");
		System.out.println("7. Consultar datos Oficina");
		System.out.println("8. Asignar Proyecto A Coordinador");
		System.out.println("9.Salir");
		System.out.println("Elige opcion:");

		int opcion;
		try {
			opcion = Integer.parseInt(Utilidades.teclado.readLine());
		} catch (NumberFormatException | IOException e) {

			e.printStackTrace();
			opcion = -1;
		}

		return opcion;
	}

}

package vista;



import java.util.regex.Matcher;
import java.util.regex.Pattern;

import modelo.Coordinador;

public class ValidarDatos {

	public static boolean validar(String cadena, String patron) {
		Pattern p = Pattern.compile(patron);
		Matcher m = p.matcher(cadena);

		if (m.matches()) {
			return true;
		}

		return false;
	}

	public static boolean comprobarDni(String dni) {
		String dniPatron = "\\d{8}[A-HJ-NP-TV-Z]";
		return validar(dni, dniPatron);
	}

	public static boolean comprobarNombre(String nombre) {
		String nombrePatron = "[a-zA-Z0-9]{5,20}";
		return validar(nombre, nombrePatron);
	}

}

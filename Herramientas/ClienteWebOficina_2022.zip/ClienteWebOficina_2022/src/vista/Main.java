package vista;

import controlador.Gestion;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import controlador.Constantes;
import modelo.Coordinador;
import modelo.Oficina;

public class Main implements Constantes{
    static final int SALIR = 9;

    public static void main(String[] args) {
        boolean resultado;
        int opcion;

        do {
            resultado = VentanaPrincipal.loguear();
        } while (!resultado);
        do {
            opcion = VentanaPrincipal.menu();
            resultado = ejecutarMenuPrincipal(opcion);
            if (resultado == true) {
                System.out.println("Consulta realizada con exito");
            } else {
                System.out.println("Error en la consulta");
            }
        } while (opcion != SALIR);
        
        //ejercicio2();
        
    }

	/*private static void ejercicio2() {
		String json="[{\"ciudad\":\"merida\",\"pais\":\"espania\",\"dni\":\"1234a\",\"nombre\":\"Encarna Balsera\"}]";
        JsonParser parser = new JsonParser();
        
        JsonArray gsonArray = parser.parse(json).getAsJsonArray();
        
        for (JsonElement jsonElement : gsonArray) {
			JsonObject gsonObj = jsonElement.getAsJsonObject();
			
			int cod_oficina = gsonObj.get("cod_oficina").getAsInt();
			String ciudad = gsonObj.get("ciudad").getAsString();
			String pais = gsonObj.get("pais").getAsString();
			String dni = gsonObj.get("dni").getAsString();
			
			Oficina oficina = new Oficina(cod_oficina,ciudad,pais,dni);
			System.out.println(oficina.toString());
		}
	}*/

    private static Boolean ejecutarMenuPrincipal(int opcion) {
        Coordinador c = null;
        Oficina of = null;
        boolean resultado = false;
        String resultado1="";
        switch (opcion) {
        case 1: {
            Coordinador coor = VentanaPrincipal.leerCoor();
            resultado1=Gestion.insertar(coor);
            resultado = resultadoFinal(resultado, resultado1);

            break;
        }
        case 2: {
            String dni = null;
            dni=VentanaPrincipal.pedirDNI();
            resultado1 = Gestion.eliminar(Coordinador.class, "dni", dni);
            resultado = resultadoFinal(resultado, resultado1);
            break;
        }
        case 3: {
            c = VentanaPrincipal.leerCoor();
            resultado1=Gestion.actualizar(c);
            resultado = resultadoFinal(resultado, resultado1);
            break;
        }
        case 4:{
        	Oficina oficina = VentanaPrincipal.leerOficina();
        	resultado1=Gestion.insertar(oficina);
            resultado = resultadoFinal(resultado, resultado1);
        	break;
        }
        case 5:{
        	System.out.println("El borrado de oficina no hace nada");
        	resultado = true;
        	break;
        }
        case 6:{
        	of = VentanaPrincipal.leerOficina();
        	resultado1 = Gestion.actualizar(of);
        	resultado = resultadoFinal(resultado, resultado1);
        	break;
        }
        case 7:{
        	int cod_oficina = VentanaPrincipal.pedirCodigoOficina();
        	System.out.println(Gestion.consultarOficina(cod_oficina));
        	break;
        }
        case 8:{
        	c= VentanaPrincipal.leerCoor();
        	resultado1 = Gestion.asignarProyectoACoordinador(c);
        	resultado = resultadoFinal(resultado, resultado1);
        	break;
        }
        case 9:
        	System.out.println("Saliendo..");
        	resultado = true;
        	break;
        default:
            System.out.println("solo se permite valores entre 1 y 8");
            throw new IllegalArgumentException("Unexpected value: " + opcion);
        }
        return resultado;

    }

	private static boolean resultadoFinal(boolean resultado, String resultado1) {
		if (resultado1.compareTo(CR_OK)==0) {
		    System.out.println("Consulta realizada correctamente!");
		    resultado = true;
		} else {
		    System.out.println("Error en la consulta!");
		}
		return resultado;
	}
}
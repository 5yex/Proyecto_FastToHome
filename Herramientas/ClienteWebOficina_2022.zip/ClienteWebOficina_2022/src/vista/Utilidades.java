package vista;

import java.io.BufferedReader;
import java.io.InputStreamReader;

public class Utilidades {
	static BufferedReader teclado=new BufferedReader(new InputStreamReader(System.in));
	
}

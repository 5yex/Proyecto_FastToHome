package controlador;

import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import java.lang.reflect.Type;
import com.google.gson.reflect.TypeToken;
import modelo.Coordinador;
import modelo.Respuesta;

public class GestionCoordinador implements Constantes {

	static public boolean logear(String dni) {
		String url = URL_CONSULTA_COORDINADOR;
		// String resultado = HttpRequest.POST_REQUEST(url, "dni="+dni);
		String resultado = HttpRequest.GET_REQUEST(url, "dni=" + dni);

		Gson gson = new Gson();
		Type listType = new TypeToken<ArrayList<Coordinador>>() {
		}.getType();
		List<Coordinador> tipoLista = new Gson().fromJson(resultado, listType);
		System.out.println(resultado);
		return tipoLista.size() > 0;
	}

	static public boolean consultaManipulacion(String url, String values) {
		Respuesta respuesta;
		String resultado = HttpRequest.POST_REQUEST(url, values);
		Gson gson = new Gson();
		respuesta = (Respuesta) gson.fromJson(resultado, Respuesta.class);
		return respuesta.getCode().compareTo(CR_OK) == 0;
	}

	static public boolean alta(Coordinador c) {
		String url = URL_INSERTAR_COORDINADOR;
		String values = "dni=" + c.getDni() + "&nombre=" + c.getNombre();
		return consultaManipulacion(url, values);
	}

	static public boolean modificar(Coordinador c) {
		String url = URL_MODIFICAR_COORDINADOR;
		String values = "dni=" + c.getDni() + "&nombre=" + c.getNombre();
		return consultaManipulacion(url, values);
	}

	static public boolean borrar(String dni) {
		String url = URL_ELIMINAR_COORDINADOR;
		return consultaManipulacion(url, dni);
	}

}

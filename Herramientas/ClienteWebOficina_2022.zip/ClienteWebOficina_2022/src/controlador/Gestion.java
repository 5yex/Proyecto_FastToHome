package controlador;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import modelo.Coordinador;
import modelo.Oficina;
import modelo.Respuesta;

public class Gestion implements Constantes {

	static public String consultaManipulacion(String url, String values) {
		Respuesta respuesta;
		String resultado = HttpRequest.POST_REQUEST(url, values);
		Gson gson = new Gson();
		respuesta = (Respuesta) gson.fromJson(resultado, Respuesta.class);
		return respuesta.getCode();
	}

	public static String insertar(Object objetoDatos) {
		
		String url = "";
		String values = "";
		
		if(objetoDatos instanceof Coordinador) {
			url = URL_INSERTAR_COORDINADOR; 
			values = "dni="+ ((Coordinador) objetoDatos).getDni() + "&nombre=" + ((Coordinador) objetoDatos).getNombre();
			
		}else if(objetoDatos instanceof Oficina){
			url = URL_INSERTAR_OFICINA;
			values = "cod_oficina=" + ((Oficina) objetoDatos).getCod_oficina() 
					+ "&ciudad=" + ((Oficina) objetoDatos).getCiudad() 
					+ "&pais=" + ((Oficina) objetoDatos).getPais() 
					+ "&dni=" + ((Oficina) objetoDatos).getDni();
			
		}
		return consultaManipulacion(url,values);
	}

	public static String actualizar(Object objetoDatos) {
		String url = "";
		String values = "";
		
		if(objetoDatos instanceof Coordinador) {
			url = URL_MODIFICAR_COORDINADOR; 
			values = "dni="+((Coordinador) objetoDatos).getDni() + "&nombre=" + ((Coordinador) objetoDatos).getNombre();
			
		}else if(objetoDatos instanceof Oficina){
			url = URL_MODIFICAR_OFICINA;
			values = "cod_oficina=" + ((Oficina) objetoDatos).getCod_oficina() 
					+ "&ciudad=" + ((Oficina) objetoDatos).getCiudad() 
					+ "&pais=" + ((Oficina) objetoDatos).getPais() 
					+ "&dni=" + ((Oficina) objetoDatos).getDni();
			
		}
		return consultaManipulacion(url,values);
	}
	
	public static String asignarProyectoACoordinador(Coordinador objetoDatos) {
		String url = "";
		String values = "";
			url = URL_ASIGNAR;
			values = "dni="+objetoDatos.getDni() + "&idproyecto=" + objetoDatos.getIdproyecto();
			

		return consultaManipulacion(url,values);
	}

	public static <T> String eliminar(java.lang.Class<T> classOfT, String nombreCampo, String valorCampo) {
		String url = "";
		String values = nombreCampo + "=" + valorCampo; 
		if(classOfT.equals(Coordinador.class)) {
			url = SERVIDOR + "eliminarCoordinador.php";
		}else {
			url = SERVIDOR + "eliminarOficina.php";
		}
		
		return consultaManipulacion(url,values);
		
	}
	
	public static String consultarOficina(int cod_oficina) {
        String url = URL_CONSULTA_DATOS_OFICINA;
        String resultado = HttpRequest.GET_REQUEST(url, "cod_oficina=" + cod_oficina);

        Gson gson = new Gson();
        Type listType = new TypeToken<ArrayList<Oficina>>() {
        }.getType();
        List<Oficina> tipoLista = new Gson().fromJson(resultado, listType);
        return resultado;
    }

}

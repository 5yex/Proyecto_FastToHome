package controlador;

public interface Constantes {
	String SERVIDOR = "http://localhost/webserviceOficina2022/vista/";
	String URL_CONSULTA_COORDINADOR = SERVIDOR + "consultarCoordinador.php";
	String URL_INSERTAR_COORDINADOR = SERVIDOR + "insertarCoordinador.php";
	String URL_MODIFICAR_COORDINADOR = SERVIDOR + "modificarCoordinador.php";
	String URL_ELIMINAR_COORDINADOR = SERVIDOR + "eliminarCoordinador.php";
	String URL_ASIGNAR = SERVIDOR + "asignarProyectoACoordinador.php";
	
	String CR_OK = "CR_OK";
	String CR_ERROR_INSERT = "CR_ERROR_INSERT";
	
	String URL_INSERTAR_OFICINA = SERVIDOR + "insertarOficina.php";
	String URL_MODIFICAR_OFICINA = SERVIDOR + "modificarOficina.php";
	String URL_CONSULTA_DATOS_OFICINA = SERVIDOR + "consultarDatosOficina.php";
	 
}
